//  Copyright (c) 2007-2017 Hartmut Kaiser
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HPX_PARALLEL_UNINITIALIZED_MOVE_MAY_30_2017_0844AM)
#define HPX_PARALLEL_UNINITIALIZED_MOVE_MAY_30_2017_0844AM

#include <hpx/parallel/algorithms/uninitialized_move.hpp>

#endif

