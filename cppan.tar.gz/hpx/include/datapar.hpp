//  Copyright (c) 2016 Hartmut Kaiser
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HPX_DATAPAR_OCT_31_2016_0305PM)
#define HPX_DATAPAR_OCT_31_2016_0305PM

#include <hpx/parallel/datapar.hpp>

#endif

